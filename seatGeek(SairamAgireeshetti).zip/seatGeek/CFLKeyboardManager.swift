//
//  CFLKeyboardManager.swift
//  CapitalFirstSales
//
//  Created by Raveendra on 26/07/17.
//  Copyright © 2017 Techjini Solutions. All rights reserved.
//

import Foundation
import UIKit

class CFLKeyboardManager:NSObject {
    
    weak fileprivate var scrollView:UIScrollView?
    
    init(_ scrollView:UIScrollView) {
        self.scrollView = scrollView
    }
    
    func beginObservingKeyboard() {
        NotificationCenter.default.addObserver(self, selector: #selector(CFLKeyboardManager.keyboardWillHide(_:)), name: UIResponder.keyboardWillHideNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(CFLKeyboardManager.keyboardWillShow(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
    }
    
    func endObservingKeyboard() {
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
    }
    
    @objc func keyboardWillShow(_ notif:Notification) {
        if let keyboardFrame = (notif.userInfo![UIResponder.keyboardFrameEndUserInfoKey] as AnyObject).cgRectValue {
            let contentInsets = UIEdgeInsets(top: scrollView!.contentInset.top, left: 0, bottom: keyboardFrame.height, right: 0)
            scrollView!.contentInset = contentInsets
            scrollView!.scrollIndicatorInsets = contentInsets
        }
    }
    
    @objc func keyboardWillHide(_ notif:Notification) {
        let contentInset = UIEdgeInsets(top: scrollView!.contentInset.top, left: 0, bottom: 0, right: 0)
        scrollView!.contentInset = contentInset
        scrollView!.scrollIndicatorInsets = contentInset
    }
    
}
