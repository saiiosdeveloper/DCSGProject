//
//  SGEvent.swift
//  seatGeek
//
//  Created by SAI RAM AGIREESHETTI on 22/04/21.
//  Copyright © 2021 sample. All rights reserved.
//

import Foundation
import UIKit



class SGEventsResponse: NSObject, Codable  {
    var events: [SGEvent]?
    var meta: SGMeta?
    
    required init(from decoder: Decoder) throws {
        
        let container = try decoder.container(keyedBy: CodingKeys.self)
        events = try container.decodeIfPresent([SGEvent].self.self, forKey: .events)
        meta = try container.decodeIfPresent(SGMeta.self, forKey: .meta)
        

       }
    
}

/*
 meta =     {
      geolocation = "<null>";
      page = 1;
      "per_page" = 20;
      took = 9;
      total = 149;
  };
 
 */

class SGMeta: NSObject, Codable {
    var per_page: Int?
    var page: Int?
    var took: Int?
    var total: Int
    
    required init(from decoder: Decoder) throws {
        
        let container = try decoder.container(keyedBy: CodingKeys.self)
        per_page = try container.decodeIfPresent(Int.self, forKey: .per_page)
        page = try container.decodeIfPresent(Int.self, forKey: .page)
        took = try container.decodeIfPresent(Int.self, forKey: .took)
        total = try container.decodeIfPresent(Int.self, forKey: .total) ?? 0

       }
    
}


class SGEvent: NSObject, Codable {
    
    /*
    
     
     "venue":{
        "state":"NY",
        "name_v2":"Palace Theatre",
        "postal_code":"12207",
        "name":"Palace Theatre",
        "links":[
           
        ],
        "timezone":"America\/New_York",
        "url":"https:\/\/seatgeek.com\/venues\/palace-theatre-5\/tickets",
        "score":0.57507,
        "location":{
           "lat":42.6545,
           "lon":-73.7502
        },
        "address":"19 Clinton Ave",
        "country":"US",
        "has_upcoming_events":true,
        "num_upcoming_events":13,
        "city":"Albany",
        "slug":"palace-theatre-5",
        "extended_address":"Albany, NY 12207",
        "id":477,
        "popularity":0,
        "access_method":null,
        "metro_code":532,
        "capacity":2844,
        "display_location":"Albany, NY"
     },
     
     "performers":[
        {
           "type":"theater_family",
           "name":"Scooby Doo Live!",
           "image":"https:\/\/seatgeek.com\/images\/performers-landscape\/scooby-doo-live-7ac648\/24879\/huge.jpg",
           "id":24879,
           "images":{
              "huge":"https:\/\/seatgeek.com\/images\/performers-landscape\/scooby-doo-live-7ac648\/24879\/huge.jpg"
           },
           "divisions":null,
           "has_upcoming_events":true,
           "primary":true,
           "stats":{
              "event_count":1
           },
           "taxonomies":[
              {
                 "id":3000000,
                 "name":"theater",
                 "parent_id":null,
                 "document_source":{
                    "source_type":"ELASTIC",
                    "generation_type":"FULL"
                 },
                 "rank":8
              },
              {
                 "id":3050000,
                 "name":"family",
                 "parent_id":3000000,
                 "document_source":{
                    "source_type":"ELASTIC",
                    "generation_type":"FULL"
                 },
                 "rank":0
              }
           ],
           "image_attribution":null,
           "url":"https:\/\/seatgeek.com\/scooby-doo-live-tickets",
           "score":0.36,
           "slug":"scooby-doo-live",
           "home_venue_id":null,
           "short_name":"Scooby Doo Live!",
           "num_upcoming_events":1,
           "colors":null,
           "image_license":null,
           "popularity":0,
           "location":null
        }
     ],
     "is_open":false,
     "links":[
        
     ],
     
     "time_tbd":true,
     "short_title":"Scooby Doo Live! - Albany",
     "visible_until_utc":"2021-04-22T04:00:00",
     "stats":{
        "listing_count":null,
        "average_price":null,
        "lowest_price_good_deals":null,
        "lowest_price":null,
        "highest_price":null,
        "visible_listing_count":null,
        "dq_bucket_counts":null,
        "median_price":null,
        "lowest_sg_base_price":null,
        "lowest_sg_base_price_good_deals":null
     },
     "taxonomies":[
        {
           "id":3000000,
           "name":"theater",
           "parent_id":null,
           "rank":8
        },
        {
           "id":3050000,
           "name":"family",
           "parent_id":3000000,
           "rank":0
        }
     ],
     "url":"https:\/\/seatgeek.com\/scooby-doo-live-albany-tickets\/family\/2021-04-21-3-30-am\/5113933",
     "score":0.313,
     "announce_date":"2019-11-13T00:00:00",
     "created_at":"2019-11-13T16:12:08",
     "date_tbd":true,
     "title":"Scooby Doo Live! - Albany",
     "popularity":0.535,
     "description":"",
     "status":"normal",
     "access_method":null,
     "event_promotion":null,
     "announcements":{
        "checkout_disclosures":{
           "messages":[
              {
                 "text":"All purchases are 100% guaranteed. Prices set by the seller may be above or below face value."
              }
           ]
        }
     },
     "conditional":false,
     "enddatetime_utc":null,
     "themes":[
        
     ],
     "domain_information":[
        
     ]
     
     */
    
    var name: String?
    var type: String?
    var id: Int?
    var datetime_utc: String?
   // var datetime_tbd: Bool
   // var is_open: Bool
   // var time_tbd: Bool
    var short_title: String?
    var url:String?
  //  var date_tbd:Bool
    var title:String?
    var status: String?
   // var conditional: Bool
    var enddatetime_utc: String?
    
    var venue:SGEventVenue?
    
    var performers:[SGEventPerformer]?
    var eventDate: Date = Date()
    
    var itemWishListed : Bool {
        let userDefaults = UserDefaults.standard
        let items:[Int] = userDefaults.object(forKey: "wishListedItem") as? [Int] ?? []
        if items.contains(self.id!) {
          return true
        }
        return false
       }
    
    required init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        name = try container.decodeIfPresent(String.self, forKey: .name)
        type = try container.decodeIfPresent(String.self, forKey: .type)
        id = try container.decode(Int.self, forKey: .id)
        datetime_utc = try container.decodeIfPresent(String.self, forKey: .datetime_utc)
        
        short_title = try container.decodeIfPresent(String.self, forKey: .short_title)
        url = try container.decode(String.self, forKey: .url)
        
        title = try container.decodeIfPresent(String.self, forKey: .title)
        short_title = try container.decodeIfPresent(String.self, forKey: .short_title)
        url = try container.decode(String.self, forKey: .url)
        venue = try container.decodeIfPresent(SGEventVenue.self, forKey: .venue)
        performers = try container.decodeIfPresent([SGEventPerformer].self.self, forKey: .performers)
        
        eventDate = DateUtility.dateForString(datetime_utc!, ForDateFormat: "yyyy-MM-dd'T'HH:mm:ss") ?? Date()
        
    }
    
    
}


class SGEventVenue: NSObject, Codable {
    var display_location: String?
    
    
    required init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
       display_location = try container.decodeIfPresent(String.self, forKey: .display_location)
        print(display_location ?? "")
        
    }
    
}


class SGEventPerformer: NSObject, Codable {
    var image: String?
    
    
    required init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
       image = try container.decodeIfPresent(String.self, forKey: .image)
        
    }
    
}

class DateUtility: NSObject {
    
    class func dateForString(_ dateString:String, ForDateFormat dateFormat:String) -> Date? {
        
        let dateFormatter        = DateFormatter()
        dateFormatter.dateFormat = dateFormat
        dateFormatter.locale     = Locale(identifier: "en_US_POSIX")
        return dateFormatter.date(from: dateString)
    }
    
    class func stringFromDate(_ date:Date, ForDateFormat dateFormat:String) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = dateFormat
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        return dateFormatter.string(from: date)
    }
}
