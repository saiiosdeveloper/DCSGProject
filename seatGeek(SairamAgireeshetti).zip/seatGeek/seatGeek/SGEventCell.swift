//
//  SGEventCell.swift
//  seatGeek
//
//  Created by SAI RAM AGIREESHETTI on 22/04/21.
//  Copyright © 2021 sample. All rights reserved.
//

import UIKit

class SGEventCell: UITableViewCell {

    var event:SGEvent?
    @IBOutlet weak var contentBgView: UIView!
    @IBOutlet weak var eventImage: UIImageView!
    @IBOutlet weak var wishList: UIButton!
    @IBOutlet weak var imgContainer: UIView!
    
    @IBOutlet weak var eventName: UILabel!
    @IBOutlet weak var eventTime: UILabel!
    @IBOutlet weak var eventLocation: UILabel!
    
    var appDelegate = UIApplication.shared.delegate as? AppDelegate
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.wishList.setImage(UIImage.init(named: "selected_Asset"), for: .selected)
        self.wishList.setImage(UIImage.init(named: "Select"), for: .normal)
        self.contentBgView.setShadow(withRadius: 5)
        self.imageView?.clipsToBounds = true
        self.imageView?.contentMode = .scaleAspectFit
        self.imgContainer.clipsToBounds = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configureCell() {
        self.wishList.isSelected    = false
        self.eventName.text         = self.event?.title ?? "--"
        self.eventTime.text         = self.event!.eventDate.formattedTime(using: "E, d MMM yyyy hh:mm:ss a")
        
        self.imageView?.image = nil
        
        self.eventLocation.text     = self.event?.venue?.display_location ?? "--"
        self.wishList.isSelected    = self.event?.itemWishListed ?? false
        
         //self.imageView?.image = UIImage.init(named: "sample")
        
        if let firstObject = self.event?.performers?[0]{
            let url = URL(string: firstObject.image!)!
            DispatchQueue.main.async {
                
               // self.imageView?.sd_setImage(with: url, completed: nil)
                
                 self.imageView?.load(url: url, placeholder: UIImage.init(named: "perfios_pdf_upload"))
              //  self.imageView?.load(url: url)
                
               // self.imageView?.layer.masksToBounds = true
            }
        }else {
            DispatchQueue.main.async {
                 self.imageView?.image = UIImage.init(named: "perfios_pdf_upload")
            }
        }
        
    }
    
    @IBAction func wishListButtonTapped(_ sender: Any) {
        
        if let eventId = self.event?.id{
            self.appDelegate?.addOrRemoveItem(forID: eventId)
        }
        self.wishList.isSelected    = self.event?.itemWishListed ?? false
    }
    
    
}
