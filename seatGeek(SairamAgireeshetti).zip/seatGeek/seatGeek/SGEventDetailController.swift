//
//  SGEventDetailController.swift
//  seatGeek
//
//  Created by SAI RAM AGIREESHETTI on 22/04/21.
//  Copyright © 2021 sample. All rights reserved.
//

import UIKit

class SGEventDetailController: UIViewController {
    
    var event:SGEvent?
    var appDelegate = UIApplication.shared.delegate as? AppDelegate
    
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var location: UILabel!
    @IBOutlet weak var time: UILabel!
    @IBOutlet weak var wishListButton: UIButton!
    @IBOutlet weak var imageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.configure()
        self.navigationController!.navigationBar.isHidden = false


        // Do any additional setup after loading the view.
    }
    
    func configure() {
        
        self.wishListButton.setImage(UIImage.init(named: "selected_Asset"), for: .selected)
        self.wishListButton.setImage(UIImage.init(named: "Select"), for: .normal)
        
        self.name.text     = self.event?.title ?? "--"
        self.location.text = self.event?.venue?.display_location ?? ""
        self.time.text     = DateUtility.stringFromDate(self.event!.eventDate, ForDateFormat: "E, d MMM yyyy hh:mm:ss")
        self.wishListButton.isSelected    = self.event?.itemWishListed ?? false
        
        if let firstObject = self.event?.performers?[0]{
                   let url = URL(string: firstObject.image!)!
                   DispatchQueue.main.async {
                        self.imageView?.load(url: url, placeholder: UIImage.init(named: "perfios_pdf_upload"))
                      // self.imageView?.load(url: url)
                       self.imageView?.clipsToBounds = true
                       self.imageView?.contentMode = UIView.ContentMode.scaleAspectFill
                       self.imageView?.layer.masksToBounds = true
                   }
               }else {
                   DispatchQueue.main.async {
                        self.imageView?.image = UIImage.init(named: "perfios_pdf_upload")
                   }
               }

    }
    
    @IBAction func wishListButtonTapped(_ sender: Any) {
        
        if let eventId = self.event?.id{
            self.appDelegate?.addOrRemoveItem(forID: eventId)
        }
        self.wishListButton.isSelected    = self.event?.itemWishListed ?? false
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
