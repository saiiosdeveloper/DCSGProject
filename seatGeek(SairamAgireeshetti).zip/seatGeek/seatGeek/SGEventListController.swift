//
//  SGEventListController.swift
//  seatGeek
//
//  Created by SAI RAM AGIREESHETTI on 22/04/21.
//  Copyright © 2021 sample. All rights reserved.
//

import UIKit
import SVProgressHUD




class SGEventListController: UIViewController {

    @IBOutlet weak var searchBar: UIView!
    @IBOutlet weak var searchContentView: UIView!
    @IBOutlet weak var eventListView: SGEventListView!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var noDataLabel: UILabel!
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var searchTextField: UITextField!
    @IBOutlet weak var cancelButton: UIButton!
    
    @IBOutlet weak var searchIcon: UIImageView!
    
    fileprivate var isAPIInProgress = false
    var currentPage: Int?
    var totalPage: Int?

    var paginationRequired : Bool {
        if let totalPages = self.totalPage,let currentPage = self.currentPage {
            return currentPage < totalPages
        }else {
            return false
        }
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController!.navigationBar.isHidden = true
        self.setupSearch()
        configureNoDataLabel()
        configureListView()
        self.searchLead(with : "")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = true
        self.navigationController!.navigationBar.isHidden = true
        self.eventListView.tableView.reloadData()
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.isNavigationBarHidden = false
        if self.searchTextField.isFirstResponder == true {
            self.searchTextField.resignFirstResponder()
        }
        NotificationCenter.default.removeObserver(self, name:UITextField.textDidChangeNotification , object: self.searchTextField)
        self.eventListView?.keyboardManger?.endObservingKeyboard()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        NotificationCenter.default.addObserver(self, selector:#selector(searchTextDidChange) , name: UITextField.textDidChangeNotification, object: self.searchTextField)
        self.eventListView?.keyboardManger?.beginObservingKeyboard()
    }
}

extension SGEventListController  : UITextFieldDelegate {
    
    func configureListView() {
        
        let viewObjs = Bundle.main.loadNibNamed("CFLRuralLeadListView", owner:self,options:nil)
        if let listView = viewObjs?.first as? SGEventListView {
            self.view.addSubview(listView)
            listView.translatesAutoresizingMaskIntoConstraints = false
            listView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor).isActive = true
            listView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor).isActive = true
            listView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor).isActive = true
            listView.topAnchor.constraint(equalTo: self.searchContentView.bottomAnchor, constant: 10.0).isActive = true

            
            listView.delegate = self
            self.eventListView = listView
        }
        self.eventListView.eventList = []
    }
    
    func configureNoDataLabel() {
        noDataLabel.text = "No Events Found"
        noDataLabel.textAlignment = .center
        noDataLabel.font = UIFont.systemFont(ofSize: 14.0, weight : .regular)
        noDataLabel.textColor = UIColor.purple
    }
    
    func setupSearch() {
        let barTintColor =  UIColor.black
        self.searchBar.backgroundColor =  UIColor.black
        self.searchContentView.backgroundColor = barTintColor
        self.searchTextField.placeholder = "Search Event"
        self.searchBar.tintColor =  UIColor(red:0.51, green:0.68, blue:0.82, alpha:1)
        searchTextField.font = UIFont.systemFont(ofSize: 14.0)
        var placeHolder = "Search Event"
        placeHolder = placeHolder.replacingOccurrences(of: "Search by", with: "...")
        searchTextField.attributedPlaceholder = NSAttributedString(string: placeHolder, attributes: [NSAttributedString.Key.foregroundColor: UIColor.white.withAlphaComponent(0.8)])
        
        searchBar.layer.cornerRadius = searchBar.frame.size.height / 2.0
        searchBar.layer.masksToBounds = true
        
        self.searchTextField.delegate = self
        self.searchTextField.backgroundColor = .clear
        self.searchTextField.textColor = .white
        self.searchTextField.borderStyle = .none
        self.searchTextField.clearButtonMode = .whileEditing
        self.searchTextField.returnKeyType = .search
        self.searchTextField.autocorrectionType = .no
        
        self.cancelButton.backgroundColor = barTintColor
        self.cancelButton.setTitleColor(UIColor.white, for: .normal)
        self.cancelButton.setTitleColor(UIColor.white, for: .highlighted)
        self.cancelButton.titleLabel?.font = UIFont.systemFont(ofSize: 14.0, weight: UIFont.Weight.semibold)
        self.cancelButton.setTitle("Cancel",for:.normal)
        self.cancelButton.setTitle("Cancel",for:.selected)
        self.cancelButton.addTarget(self, action: #selector(cancelSearch), for: .touchUpInside)
        
    }
    
    @objc func searchTextDidChange(notification: NSNotification) {
        
         self.eventListView.eventList = []
        if let searchText = self.searchTextField.text{
            self.searchLead(with : searchText)
        }
            return
        }
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        if let _ = textField.text, let _ = self.eventListView {
            self.eventListView.isHidden = false
            
        }
        self.searchTextField.resignFirstResponder()
        return true
    }
    
    func textFieldDidEndEditing(_ textField : UITextField) {
        if let searchText = textField.text{
            self.searchLead(with : searchText)
        }
    }
    
    @objc func cancelSearch() {
        self.searchTextField.text = ""
        self.searchTextField.resignFirstResponder()
        self.dismiss(animated : true, completion: nil)
    }
    
    private func searchLead(with searchkey : String, page : Int = 1) {
        
       
        
        if page == 1 {
            self.eventListView.eventList = []
            
            SVProgressHUD.show(withStatus: "Loading")

            
        }
        self.isAPIInProgress = true
        
        
        let session = URLSession.shared
        let clientID = "MjE3NjY1MDN8MTYxOTA2MTM1MC44NDgwMTE3"
        var q=""
        if(searchkey.count > 0){
            q = String("&q=\(searchkey)")
        }
        
        let sgURL =  String(format: String("https://api.seatgeek.com/2/events?client_id=\(clientID)&per_page=20&page=\(page)\(q)"))
        
        
        let url = URL(string: sgURL)!
        
        let task = session.dataTask(with: url, completionHandler: { data, response, error in
        
            
           var eventList = [SGEvent]()
            
            guard error == nil else {
                self.updateEventList(with : eventList)
                return
            }
            guard let data = data else {
                self.updateEventList(with : eventList)
                return
            }
            do {
                 let decoder = JSONDecoder()
                let response = try decoder.decode(SGEventsResponse.self, from: data)
                print(response)
                
                if page > 1 {
                                   eventList.append(contentsOf:self.eventListView.eventList ?? [])
                               }
                               eventList.append(contentsOf:(response.events ?? []))
                            self.currentPage = response.meta?.page ?? 0
                            self.totalPage = response.meta?.total ?? 0

            } catch {
                print(error)
            }
            
            DispatchQueue.main.async {
                           SVProgressHUD.dismiss()
                       }
            self.isAPIInProgress = false
            
            self.updateEventList(with : eventList)
            
            
            
        })
        task.resume()
        
        /*
        
        CFLNetworkService.shared.startService(request: PNetworkRouter.fetchRuralLeadList(params: params)) { (response) in
            
            var taskDetails = [CFLRuralVLTaskDetails]()
            if let responseDictionary = response as? [String: Any], let code = responseDictionary["code"] as? Int, code == 200, let data = responseDictionary["data"] as? [String: Any] {
                let jsonData = try! JSONSerialization.data(withJSONObject: data, options: .prettyPrinted)
                do {
                    let decoder = JSONDecoder()
                    let detail = try decoder.decode(CFLRuralVLAssignedLeadResponse.self, from: jsonData)
                    if page > 1 {
                        taskDetails.append(contentsOf:self.leadListView.leadsList ?? [])
                    }
                    taskDetails.append(contentsOf:(detail.taskDetail ?? []))
                    self.currentPage = detail.currentPage
                    self.totalPage = detail.totalPages
                    
                  
                } catch {
                    taskDetails = []
                    print (error)
                }
            }
            self.updateEventList(with : taskDetails)
        }
        */

    }
    
    private func updateEventList(with events : [SGEvent]) {
        
        DispatchQueue.main.async {
            self.eventListView.eventList  = events
            self.eventListView.isHidden = events.isEmpty
        }
    }
}

extension SGEventListController : SGEventDelegate {

    
    
     func didSelectEvent(event:SGEvent ){
        
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyBoard.instantiateViewController(withIdentifier: "SGEventDetailController") as! SGEventDetailController
        
        viewController.event = event
       
        self.navigationController?.pushViewController(viewController, animated: true)
    }
    
    func eventListDidScrollToEnd() {
        // Change 10.0 to adjust the distance from bottom
        if !isAPIInProgress && self.paginationRequired {
            if let currentPage = currentPage {
                self.searchLead(with : self.searchTextField.text ?? "",page : currentPage + 1)
            }
        }
    }
    
    func isPaginationEnabled() -> Bool {
        return self.paginationRequired
    }
}

