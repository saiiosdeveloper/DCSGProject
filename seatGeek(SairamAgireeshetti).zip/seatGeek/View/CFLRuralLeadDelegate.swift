//
//  SGEventDelegate.swift
//  seatGeek
//
//  Created by SAI RAM AGIREESHETTI on 22/04/21.
//  Copyright © 2021 sample. All rights reserved.
//

import Foundation

protocol SGEventDelegate {
    func didSelectEvent(event:SGEvent )
    func eventListDidScrollToEnd()
    func isPaginationEnabled() -> Bool
}
