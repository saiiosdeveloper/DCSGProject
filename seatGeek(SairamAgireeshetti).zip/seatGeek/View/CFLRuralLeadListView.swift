//
//  SGEventListView.swift
//  seatGeek
//
//  Created by SAI RAM AGIREESHETTI on 22/04/21.
//  Copyright © 2021 sample. All rights reserved.
//

/*
    Custom class to display the lead list.
 The class will have the table view to display the leads.
 And provide custom cells.
 
 API request is not part of views operation, and needs the parent VC to proivde the data to display.
 */

import UIKit

class SGEventListView: UIView {

    
    @IBOutlet weak var tableView: UITableView!{
        didSet {
            keyboardManger = CFLKeyboardManager(tableView)
        }
    }
    
    var eventList : [SGEvent]?  {
        didSet {
            self.prepareCellDataSource()
        }
    }

    var delegate : SGEventDelegate?
    var keyboardManger: CFLKeyboardManager?
    
    lazy var footerView  = { () -> UIView in
        let footerView = UIView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 50))
        footerView.backgroundColor = .clear
        let activityIndicator = UIActivityIndicatorView(style: UIActivityIndicatorView.Style.medium)
        activityIndicator.startAnimating()
        activityIndicator.center = footerView.center
        footerView.addSubview(activityIndicator)
        return footerView
    }

     
    required init?(coder: NSCoder) {
        super.init(coder : coder)
    }
    
    override  func awakeFromNib() {
        super.awakeFromNib()
        self.setupTableView()
    }
    
    private func setupTableView() {
        self.backgroundColor = UIColor.white
        self.tableView.backgroundColor = UIColor.black
        self.tableView.separatorStyle = .none
        self.tableView.separatorColor = .clear
        self.tableView.translatesAutoresizingMaskIntoConstraints = false
        self.registerCells()
        self.tableView.delegate = self
        self.tableView.dataSource = self
    }
    
    /// Register Cells
    private func registerCells() {
        self.tableView.register(UINib(nibName: "SGEventCell", bundle: nil),
                                         forCellReuseIdentifier: "SGEventCell")
        
    }
    
    
    
    /// TableViewData Source
    private func prepareCellDataSource() {
       
        if let detail = eventList, detail.count > 0 {
            self.tableView.isHidden = false
        } else {
            self.tableView.isHidden = true
        }
        self.setupFooterView()
        self.tableView.reloadData()
    }
    
    /// TableView Footer Setup
    private func setupFooterView() {
        if self.delegate?.isPaginationEnabled() == true {
            self.tableView.tableFooterView = footerView()
        }else {
            self.tableView.tableFooterView = UIView(frame: CGRect.zero)
        }
    }
    

    
}


extension SGEventListView: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.eventList?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        return self.getEventListCell(forIndexPath: indexPath)
     }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.delegate?.didSelectEvent(event: self.eventList![indexPath.row])
    }

    
}

extension SGEventListView {
    
    fileprivate func getEventListCell(forIndexPath indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SGEventCell",
                                                          for: indexPath) as! SGEventCell
        cell.event = self.eventList?[indexPath.row]
        cell.configureCell()
        return cell
    }
    
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        // UITableView only moves in one direction, y axis
        let currentOffset = scrollView.contentOffset.y
        let maximumOffset = scrollView.contentSize.height - scrollView.frame.size.height
        
        print("Current value ", maximumOffset - currentOffset)
        
        if maximumOffset - currentOffset <= 10.0 {
            self.delegate?.eventListDidScrollToEnd()
        }
    }
}
