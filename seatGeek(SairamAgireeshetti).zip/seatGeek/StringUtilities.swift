//
//  StringUtilities.swift
//  seatGeek
//
//  Created by SAI RAM AGIREESHETTI on 22/04/21.
//  Copyright © 2021 sample. All rights reserved.
//

import Foundation
import UIKit

enum MimeType: String {
    case mimeTypePdf = "application/pdf"
    case mimeTypeJpeg = "image/jpeg"
    case mimeTypePng = "image/png"
}

extension String {
    var isAlphanumeric: Bool {
        return !isEmpty && range(of: "[^a-zA-Z0-9]", options: .regularExpression) == nil
    }
    
    var isAlphaNumericWithSpace: Bool {
        return isEmpty || range(of: "[^a-zA-Z0-9 ]+$", options: .regularExpression) == nil
    }
    
    var isAlphabetic: Bool {
        return !isEmpty && range(of: "[^A-Z]", options: .regularExpression) == nil
    }
    
    var removeEscapeChar: String {
        return self.replacingOccurrences(of: "\n", with: "").replacingOccurrences(of: "\t", with: "")
    }
    
    var isValidNewTwField: Bool {
        return !isEmpty && range(of: "[^A-Z0-9]", options: .regularExpression) == nil
    }
    
    func date(using format:String) -> Date? {
        let formatter = DateFormatter()
        formatter.dateFormat = format
        return formatter.date(from: self)
    }
    
    var isValidPhoneNumber : Bool {
        let regex = "^[6789]\\d{9}$"
        let numberTest = NSPredicate.init(format: "SELF MATCHES %@", regex)
        return numberTest.evaluate(with: self)
    }
    
    var url:URL? {
        return URL(string: self.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!)
    }
    
    var trim: String {
        return self.trimmingCharacters(in: .whitespacesAndNewlines)
    }
    
    var floatValue : Double {
        let string = self.replacingOccurrences(of: ",", with: "")
        guard let number = NumberFormatter().number(from: string) else {
            return 0.0
            
        }
        return Double(truncating: number)
    }
    
    var isValidNumber : Bool {
        print(self.rangeOfCharacter(from: CharacterSet.decimalDigits.inverted) == nil)
        return !self.isEmpty && self.rangeOfCharacter(from: CharacterSet.decimalDigits.inverted) == nil
    }
    
    /*Validate Name*/
    var isValidName: Bool {
        let regex =  "[a-zA-Z ]+"
        let nameTest = NSPredicate.init(format: "SELF MATCHES %@", regex)
        return nameTest.evaluate(with: self)
    }
    
    //To check if the String is blank or not
    var isBlank: Bool {
        get {
            let trimmed = trimmingCharacters(in: CharacterSet.whitespaces)
            return trimmed.isEmpty
        }
    }

    /*get digits from string */
    var digits: String {
        return components(separatedBy: CharacterSet.decimalDigits.inverted).joined()
    }
    
    /*Validate email */
    var isValidEmail: Bool {
        let emailFormat = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$"
        let emailPredicate = NSPredicate(format:"SELF MATCHES %@", emailFormat)
        return emailPredicate.evaluate(with: self)
    }
    
    /*Validate PAN Detail */
    var isValidPersonalOrCorpPAN: Bool {
        return self.isValidPAN || self.isValidCorpPAN
    }
    
    var isValidPAN: Bool {
        let panFormat = "^[A-Z]{3}P[A-Z]{1}[0-9]{4}[A-Z]{1}$"
        let panPredicate = NSPredicate(format:"SELF MATCHES %@", panFormat)
        return panPredicate.evaluate(with: self)
    }
    
    var isValidCorpPAN: Bool {
        let panFormat = "^[A-Z]{3}[CHFATBLEJG]{1}[A-Z]{1}[0-9]{4}[A-Z]{1}$"
        let panPredicate = NSPredicate(format:"SELF MATCHES %@", panFormat)
        return panPredicate.evaluate(with: self)
    }
    
    /*Validate passport */
    var isValidPassport: Bool {
        let format = "[A-Za-z]{1}[0-9]{6,9}"
        let predicate = NSPredicate(format:"SELF MATCHES %@", format)
        return predicate.evaluate(with: self)
    }
    
    /*Validate GSTIN */
    var isValidGSTIN: Bool {
        let format = "^[0-9]{2}[A-Z]{3}[CHFATBLEJG][A-Z][0-9]{4}[A-Z][0-9][A-Z][0-9]$"
        let predicate = NSPredicate(format:"SELF MATCHES %@", format)
        return predicate.evaluate(with: self)
    }
    
    /*Validate voterId */
    var isValidVoterId: Bool {
        let format1 = "[A-Za-z]{3}[0-9]{6,17}"
        let format2 = "[A-Za-z]{2}[0-9]{7,18}"
        let predicate = NSPredicate(format:"(SELF MATCHES %@) OR (SELF MATCHES %@)", format1,format2)
        return predicate.evaluate(with: self)
    }
    
    var isValidDrivingLicense: Bool{
        let drvingLicenseFormat = "[A-Za-z]{2}[0-9]{13}"
        let drvingLicensePredicate = NSPredicate(format:"SELF MATCHES %@", drvingLicenseFormat)
        return drvingLicensePredicate.evaluate(with: self)
    }

    var isValidAddress: Bool {
        if(self.isEmpty || self.isBlank){
            return false
        }
        let addressFormat = "[a-zA-Z0-9 .,-\\/]*"
        let addressPredicate = NSPredicate(format:"SELF MATCHES %@", addressFormat)
        return addressPredicate.evaluate(with: self)
    }
    
    var isValidAddressHL: Bool {
        if (self.isEmpty || self.isBlank || self.count < 8) {
            return false
        }
        let addressFormat = "[a-zA-Z0-9 .:,+#-\\/]*"
        let addressPredicate = NSPredicate(format:"SELF MATCHES %@", addressFormat)
        return addressPredicate.evaluate(with: self)
    }
    
    var isValidAadhaar: Bool {
        let aadhaarFormat = "^[2-9]{1}[0-9]{11}$"
        let predicate = NSPredicate(format:"SELF MATCHES %@", aadhaarFormat)
        return predicate.evaluate(with: self)
    }
    
    func getHoursFromTimeString() -> Int {
        
        let stringComponents = self.components(separatedBy: ":")
        if(stringComponents.count > 0){
            
            let hour = Int(stringComponents.first ?? "0") ?? 0
//            if(self.contains("pm") && hour <  12) {
//                return hour + 12
//            }
            return hour
        }
        return 0
    }
    
    func getMinutesFromTimeString() -> Int {
        let firstComponent = self.components(separatedBy: " ")
        let stringComponents =  firstComponent.first?.components(separatedBy: ":") ?? [""]
        if(stringComponents.count > 1){
            
            let minutes = Int(stringComponents.last ?? "0") ?? 0
            return minutes
        }
        return 0
    }
    
    var validPinCode : Bool {
        let regex = "^[1-9][0-9]{5}$"
        let numberTest = NSPredicate.init(format: "SELF MATCHES %@", regex)
        return numberTest.evaluate(with: self)
    }
    
    static func randomString(ofLength length: Int) -> String {
        let letters : NSString = "1234567890"
        let len = UInt32(letters.length)
        
        var randomString = ""
        for _ in 0 ..< length {
            let rand = arc4random_uniform(len)
            var nextChar = letters.character(at: Int(rand))
            randomString += NSString(characters: &nextChar, length: 1) as String
        }
        
        return randomString
    }
    
    var isValidEngineNumber: Bool {
        let engineNumberFormat = "^[0-9]{2}[A-Z]{3}[0-9]{5}$"
        let engineNumberPredicate = NSPredicate(format:"SELF MATCHES %@", engineNumberFormat)
        return engineNumberPredicate.evaluate(with: self)
    }
    
    var isValidRegistrationNumber: Bool {
        let registrationNumberFormat = "^[A-Z]{2}[0-9]{1,2}[A-Z]{1,2}[0-9]{4}$"
        let registrationNumberPredicate = NSPredicate(format:"SELF MATCHES %@", registrationNumberFormat)
        return registrationNumberPredicate.evaluate(with: self)
    }
    
    var isValidChassisNumber: Bool {
        let chassisNumberFormat = "^[0-9]{6}$"
        let chassisNumberPredicate = NSPredicate(format:"SELF MATCHES %@", chassisNumberFormat)
        return chassisNumberPredicate.evaluate(with: self)
    }

    var getNames: (firstName: String?, middleName: String?, lastName: String?) {
        get {
            let names = self.components(separatedBy: " ")
            switch names.count {
            case 0:
                return (nil, nil, nil)
            case 1:
                return (names.first, nil, nil)
            case 2:
                return (names.first, nil, names.last)
            default:
                let lastNames = names[2..<names.endIndex]
                return (names.first, names[1], lastNames.joined(separator: " "))
            }
        }
    }
    
    var isWhiteSpace: Bool {
        if let _ = self.rangeOfCharacter(from: .whitespaces), self.isBlank {
            return true
        }
        return false
    }
    
    var bool: Bool? {
        let lowercaseSelf = self.lowercased()
        switch lowercaseSelf {
        case "true", "yes", "1":
            return true
        case "false", "no", "0":
            return false
        default:
            return nil
        }
    }
    
    static func displayString(from str : String?) -> String {
        guard let displayStr = str else {
            return "--"
        }
        if displayStr.isBlank {
            return "--"
        }
        return displayStr
    }
}


extension UIView {
    func setShadow(withRadius radius: CGFloat = 3) {
        self.layer.shadowOffset = CGSize.zero
        self.layer.shadowColor = UIColor.gray.cgColor
        self.layer.shadowOpacity = 1
        self.layer.shadowRadius = radius
    }
}


extension UIImageView {
    /// Loads image from web asynchronosly and caches it, in case you have to load url
    /// again, it will be loaded from cache if available
    func load(url: URL, placeholder: UIImage?, cache: URLCache? = nil) {
        let cache = cache ?? URLCache.shared
        let request = URLRequest(url: url)
        if let data = cache.cachedResponse(for: request)?.data, let image = UIImage(data: data) {
            self.image = image
        } else {
            self.image = placeholder
            URLSession.shared.dataTask(with: request, completionHandler: { (data, response, error) in
                if let data = data, let response = response, ((response as? HTTPURLResponse)?.statusCode ?? 500) < 300, let image = UIImage(data: data) {
                    let cachedData = CachedURLResponse(response: response, data: data)
                    cache.storeCachedResponse(cachedData, for: request)
                    self.image = image
                }
            }).resume()
        }
    }
    
    
    
    
}

extension UIImageView {
    func load(url: URL) {
        DispatchQueue.global().async { [weak self] in
            if let data = try? Data(contentsOf: url) {
                if let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        self?.image = image
                    }
                }
            }
        }
    }
}


extension Date {
    func getAbbriviationByTimeZone() -> String {
        let timeZone = TimeZone.current.identifier
        switch timeZone {
        case "America/Juneau":
            return "AKDT"
        case "America/Argentina/Buenos_Aires":
            return "ART"
        case "America/Halifax":
            return "AST"
        case "Asia/Dhaka":
            return "BDT"
        case "America/Sao_Paulo":
            return "BRT"
        case "Europe/London":
            return "BST"
        case "Africa/Harare":
            return "CAT"
        case "Europe/Paris":
            return "CET"
        case "America/Santiago":
            return "CLT"
        case "America/Bogota":
            return "COT"
        case "America/Chicago":
            return "CST"
        case "Africa/Addis_Ababa":
            return "EAT"
        case "Europe/Istanbul":
            return "EET"
        case "America/New_York":
            return "EST"
        case "Asia/Dubai":
            return "GST"
        case "Asia/Hong_Kong":
            return "HKT"
        case "Pacific/Honolulu":
            return "HST"
        case "Asia/Bangkok":
            return "ICT"
        case "Asia/Tehran":
            return "IRST"
        case "Asia/Kolkata":
            return "IST"
        case "Asia/Tokyo":
            return "JST"
        case "Asia/Seoul":
            return "KST"
        case "Europe/Moscow":
            return "MSK"
        case "America/Denver":
            return "MST"
        case "Pacific/Auckland":
            return "NZST"
        case "America/Lima":
            return "PET"
        case "Asia/Manila":
            return "PHT"
        case "Asia/Karachi":
            return "PKT"
        case "America/Los_Angeles":
            return "PST"
        case "Asia/Singapore":
            return "SGT"
        case "Africa/Lagos":
            return "WAT"
        case "Europe/Lisbon":
            return "WET"
        case "Asia/Jakarta":
            return "WIT"
        default:
            return ""
        }
    }
    
    func string(using format: String) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = format
        formatter.locale = Locale(identifier: "en_US_POSIX")
        return formatter.string(from: self)
    }
    
    func formattedTime(using format: String) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = format
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.amSymbol = "am"
        formatter.pmSymbol = "pm"
        return formatter.string(from: self)
    }
    
    func getTimestampForImageUpload() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "E MMM dd HH:mm:ss "
        let baseDateString = formatter.string(from: self)
        
        let timezoneString = self.getAbbriviationByTimeZone()
        
        formatter.dateFormat = " yyyy"
        let yearString = formatter.string(from: self)
        
        return baseDateString + timezoneString + yearString
    }
    
    func indianFormattedString() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        return formatter.string(from: self)
    }
    
    func time() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "h:mm a"
        return formatter.string(from: self)
    }
    
    func getDateStringWithSuffix(with format:String = "MMM yyyy") -> String{
        let calendar = Calendar.current
        let anchorComponents = calendar.dateComponents([.day, .month, .year], from: self)
        
        let dateFormate = DateFormatter()
        dateFormate.dateFormat = format
        let newDate = dateFormate.string(from: self)
        
        var day  = "\(anchorComponents.day!)"
        switch (day) {
        case "1" , "21" , "31":
            day.append("st")
        case "2" , "22":
            day.append("nd")
        case "3" ,"23":
            day.append("rd")
        default:
            day.append("th")
        }
        return day + " " + newDate
    }
    
    func getDateStringDifferenceFromCurrentDate() -> String {
        let differenceInTime = Calendar.current.dateComponents([.day,.month,.year,.hour,.minute,.second], from: self, to: Date())
        
        if let year = differenceInTime.year, year > 0 {
            return string(using: "dd MMM, yyyy")
        }else if let days = differenceInTime.day, days > 6 {
            return string(using: "dd MMM")
        }else if let days = differenceInTime.day, days > 1 {
            return string(using: "EEEE")
        }else if let day = differenceInTime.day, day == 1 {
            return "Yesterday"
        }else if let hours = differenceInTime.hour, hours > 0 {
            if hours == 1 {
                return "1 hour ago"
            }else {
                return "\(hours) hours ago"
            }
        }else if let mins = differenceInTime.minute, mins > 0 {
            if mins == 1 {
                return "1 minute ago"
            }else {
                return "\(mins) minutes ago"
            }
        }else {
            return "Few Seconds ago"
        }
    }
    
    func onlyDate() -> Date {
        let dateString = "dd MM yyyy"
        return self.string(using: dateString).date(using: dateString) ?? Date()
    }
    
    func onlyMonthAndYear(with format:String = "MMM yyyy") -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = format
        let monthYearString = formatter.string(from: self)
        return monthYearString
    }
    
    
    func dateAt(hours: Int, minutes: Int) -> Date{
        let calendar = NSCalendar(calendarIdentifier: NSCalendar.Identifier.gregorian)!
        
        //get the month/day/year componentsfor today's date.
        
        
        var date_components = calendar.components(
            [NSCalendar.Unit.year,
             NSCalendar.Unit.month,
             NSCalendar.Unit.day],
            from: self)
        
        //Create an NSDate for the specified time today.
        date_components.hour = hours
        date_components.minute = minutes
        date_components.second = 0
        
        let newDate = calendar.date(from: date_components)!
        return newDate
    }
    
    func is24HourFormat() -> Bool {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        formatter.dateStyle = .none
        let dateString = formatter.string(from: self)
        return !(dateString.contains(formatter.amSymbol) || dateString.contains(formatter.pmSymbol))
    }
    
    func convertDateformate_24_to12_andReverse(str_date : String , strdateFormat: String, inputFormat: String) -> String{
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = inputFormat
        dateFormatter.timeZone = NSTimeZone(forSecondsFromGMT: 0) as TimeZone
        
        let date = dateFormatter.date(from: str_date)
        dateFormatter.dateFormat = strdateFormat
        let datestr = dateFormatter.string(from: date!)
        return datestr
    }
    
    func convertDateToUTCFormat() -> String{
        // create dateFormatter with UTC time format
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "M/d/yyyy HH:mm:ss a"
        dateFormatter.amSymbol = "AM"
        dateFormatter.pmSymbol = "PM"
        dateFormatter.timeZone = NSTimeZone(name: "UTC") as TimeZone?
        let utcDateString = dateFormatter.string(from: self)
        return utcDateString
    }
}


extension UIImage {

func crop(to:CGSize) -> UIImage {

    guard let cgimage = self.cgImage else { return self }

    let contextImage: UIImage = UIImage(cgImage: cgimage)

    guard let newCgImage = contextImage.cgImage else { return self }

    let contextSize: CGSize = contextImage.size

    //Set to square
    var posX: CGFloat = 0.0
    var posY: CGFloat = 0.0
    let cropAspect: CGFloat = to.width / to.height

    var cropWidth: CGFloat = to.width
    var cropHeight: CGFloat = to.height

    if to.width > to.height { //Landscape
        cropWidth = contextSize.width
        cropHeight = contextSize.width / cropAspect
        posY = (contextSize.height - cropHeight) / 2
    } else if to.width < to.height { //Portrait
        cropHeight = contextSize.height
        cropWidth = contextSize.height * cropAspect
        posX = (contextSize.width - cropWidth) / 2
    } else { //Square
        if contextSize.width >= contextSize.height { //Square on landscape (or square)
            cropHeight = contextSize.height
            cropWidth = contextSize.height * cropAspect
            posX = (contextSize.width - cropWidth) / 2
        }else{ //Square on portrait
            cropWidth = contextSize.width
            cropHeight = contextSize.width / cropAspect
            posY = (contextSize.height - cropHeight) / 2
        }
    }

    let rect: CGRect = CGRect(x: posX, y: posY, width: cropWidth, height: cropHeight)

    // Create bitmap image from context using the rect
    guard let imageRef: CGImage = newCgImage.cropping(to: rect) else { return self}

    // Create a new image based on the imageRef and rotate back to the original orientation
    let cropped: UIImage = UIImage(cgImage: imageRef, scale: self.scale, orientation: self.imageOrientation)

    UIGraphicsBeginImageContextWithOptions(to, false, self.scale)
    cropped.draw(in: CGRect(x: 0, y: 0, width: to.width, height: to.height))
    let resized = UIGraphicsGetImageFromCurrentImageContext()
    UIGraphicsEndImageContext()

    return resized ?? self
  }
}
